
public enum ID {
	player(),
	Block(),
	Crate(),
	Bullet(),
	Enemy(),
}
